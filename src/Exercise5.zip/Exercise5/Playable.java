package Exercise5;

public interface Playable {
    int MAX_VOLUME = 100;

}
