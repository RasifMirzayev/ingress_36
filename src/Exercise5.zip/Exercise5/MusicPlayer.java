package Exercise5;

public class MusicPlayer implements Playable{
    
}
