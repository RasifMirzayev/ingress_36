package Exercise5;

public class Run {
    public static void main(String[] args) {
        MusicPlayer musicPlayer = new MusicPlayer();
        System.out.println("The maximum volume is: " +Playable.MAX_VOLUME);

        // Izah interface də dəyisənlər sabitdir ve deyisdirile bilmez
        //Sabit dəyişənlər yalnız bir dəfə təyin olunur və sonradan bu dəyişənə yeni dəyər vermək mümkün deyil.

    }
}
