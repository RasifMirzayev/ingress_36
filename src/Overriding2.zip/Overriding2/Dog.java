package Overriding2;

 class Dog extends Animal{
    public static void speak() {
        System.out.println("Dog Barks ");
    }
}
