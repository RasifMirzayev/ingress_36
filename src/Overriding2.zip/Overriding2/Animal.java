package Overriding2;

public class Animal {
    public static void speak() {
        System.out.println("Animal speaks");
    }
}
