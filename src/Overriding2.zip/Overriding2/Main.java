package Overriding2;

public class Main {
    public static void main(String[] args) {
        //Heyvanın obyekti:
        Animal animal = new Animal();
        animal.speak(); // Animal speak
        Animal.speak(); //Animal speak



        Animal dogAsAnimal= new Dog();
        dogAsAnimal.speak();
        Animal.speak();


        //   İtin öz obyekti
        Dog dog = new Dog();
        dog.speak(); // dog barks
        Dog.speak(); // dog barks
    }
}
