package Overriding;

 class Calculator {

     public int add(int a, int b ) {
         return a+b;

     }

     public double add(double a , double b) {
         return a+b;
     }
}
