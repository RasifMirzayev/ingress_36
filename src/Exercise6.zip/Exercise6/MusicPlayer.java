package Exercise6;

public class MusicPlayer implements Playable{

}
