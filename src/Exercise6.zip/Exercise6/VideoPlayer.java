package Exercise6;

public class VideoPlayer implements Playable{
    @Override
    public void defaultplayMessage() {
        System.out.println("Playing video...");
    }
}
