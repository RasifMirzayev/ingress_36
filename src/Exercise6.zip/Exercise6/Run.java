package Exercise6;

public class Run {
    public static void main(String[] args) {
        MusicPlayer musicPlayer = new MusicPlayer();
        musicPlayer.defaultplayMessage();


        VideoPlayer videoPlayer = new VideoPlayer();
        videoPlayer.defaultplayMessage();
    }
}
