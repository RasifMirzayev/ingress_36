package Exercise6;

public interface Playable {
     default void defaultplayMessage() {
        System.out.println("Playing media...");
    }
}
