package Exercise4;

public class AmphibiousPlane implements Flyable,Swimmable{
    @Override
    public void fly() {
        System.out.println("AmphibiousPlane is flying in the sky.");
    }

    @Override
    public void swim() {
        System.out.println("AmphibiousPlane is swimming in the water.");
    }
}
