package Exercise4;

public interface Swimmable {
    void swim();
}
