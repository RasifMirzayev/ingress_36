package Exercise4;

public interface Flyable {
    void fly();

}
