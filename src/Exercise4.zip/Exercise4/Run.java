package Exercise4;

public class Run {
    public static void main(String[] args) {

        AmphibiousPlane amphibiousPlane = new AmphibiousPlane();
        amphibiousPlane.fly();
        amphibiousPlane.swim();
    }
}
