package Overriding4;

public class Car {
    public void startEngine() {
        System.out.println("Car engine started:");
    }
}
