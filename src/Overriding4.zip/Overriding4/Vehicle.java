package Overriding4;

public class Vehicle {
    public final void startEngine() {
        System.out.println("Engine started:");

        // İzah : Biz Vehicle sinifinde startEngine(); metodunu final etmisik ve bilirik ki final keywordu @Override desteklemir.
        // Ona gore compile xetasi aliriq. Bu xatanı final keywordunu silerek aradan qaldıra bilerik

    }
}
