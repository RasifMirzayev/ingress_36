package Overriding3;

 class Derived extends Base {

     public  void show() {
         System.out.println(" Derived class Show(); method called");
     }
     public static void display() {
         System.out.println(" Derived Display() static method called ");
     }
 }

