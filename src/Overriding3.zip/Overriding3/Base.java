package Overriding3;

 abstract class Base {
     public  void show() {
         System.out.println("<Base>  Show method :");
     }

     public static void display() {
         System.out.println("<Base> class  Display static  method ");
     }

 }
