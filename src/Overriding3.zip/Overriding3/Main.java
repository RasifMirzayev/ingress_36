package Overriding3;

public class Main {
    public static void main(String[] args) {

        Base bs = new Derived();
        bs.show();
        bs.display();


        // Burada bs dəyişəni Base tipində olsada Əsas obyekt Derived tipindedir. Ve runtime zamanı Derived sinifinin show();
        // metoduna baxilacaq

        // display(); metodu static olduğuna göre obyekte baxılmayacaq. Yeni burada bs deyişeni Base tipinde oldğu üçün
        //Base sinifinin static display(); metoduna baxilacaq

    }
}
