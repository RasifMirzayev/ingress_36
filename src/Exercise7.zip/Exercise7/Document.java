package Exercise7;

public class Document implements Readable, Printable{
    @Override
    public void display() {
        Readable.super.display();
        Printable.super.display();
    }
}
