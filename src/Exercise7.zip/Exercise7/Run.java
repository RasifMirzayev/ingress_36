package Exercise7;

public class Run {
    public static void main(String[] args) {
        Document doc = new Document();
        System.out.println("");
        System.out.println("<Document>");
        doc.display();


        Readable read = new Document();
        System.out.println("");
        System.out.println("<Readable>");
        read.display();


        Printable print = new Document();
        System.out.println("");
        System.out.println("<Printable>");
        print.display();

    }
}
