package Exercise1;

public class Run {
    public static void main(String[] args) {
        MusicPlayer musicPlayer = new MusicPlayer();
        System.out.println("<MusicPlayer>");
        musicPlayer.play();
        musicPlayer.stop();

        System.out.println("-----------------");


        VideoPlayer videoPlayer = new VideoPlayer();
        System.out.println("<VideoPlayer>");
        videoPlayer.play();
        videoPlayer.stop();
    }
}
