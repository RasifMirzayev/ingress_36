package Exercise1;

public interface Playable {
    void play();
    void stop();


}
