package Overriding5;

public class Person {
    public String name;

}
