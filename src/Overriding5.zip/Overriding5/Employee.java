package Overriding5;

public class Employee extends Person {

}
