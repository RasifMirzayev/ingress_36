package Overriding5;

public class Main {
    public static void main(String[] args) {
        Employee employee =new Employee();
        employee.name = "Rasif";


        Person person =  employee;
        person.name = "Kənan";


        System.out.println("Employee name:" +employee.name);
        System.out.println("Person name:" +person.name);
    }
}
