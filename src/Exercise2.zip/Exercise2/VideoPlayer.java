package Exercise2;

public class VideoPlayer implements AdvancedPlayable{
    @Override
    public void pause() {
        System.out.println("Video is pausing");
    }

    @Override
    public void play() {
        System.out.println("Video is playing");

    }

    @Override
    public void stop() {
        System.out.println("Video is stoping ");

    }
}
