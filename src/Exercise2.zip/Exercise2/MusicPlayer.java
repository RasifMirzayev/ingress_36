package Exercise2;

public class MusicPlayer implements AdvancedPlayable {
    @Override
    public void pause() {
        System.out.println("Music is pausing");
    }

    @Override
    public void play() {
        System.out.println("Music is playing");

    }

    @Override
    public void stop() {
        System.out.println("Music is stoping");

    }
}
