package Exercise2;

public interface Playable {
    void play();
    void stop();

}
