package Exercise2;

public class Run {
    public static void main(String[] args) {

        MusicPlayer musicPlayer = new MusicPlayer();
        System.out.println("<MusicPlayer>");
        musicPlayer.play();
        musicPlayer.stop();
        musicPlayer.pause();

        System.out.println("-----------------");

        VideoPlayer videoPlayer = new VideoPlayer();
        System.out.println("<VideoPlayer>");
        videoPlayer.play();
        videoPlayer.stop();
        videoPlayer.pause();
    }
}
