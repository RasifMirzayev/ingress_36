package Exercise2;

public interface AdvancedPlayable extends Playable{
    void pause();

}
