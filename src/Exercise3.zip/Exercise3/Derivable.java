package Exercise3;

public interface Derivable {
    void accelerate();
    void brake();
}
