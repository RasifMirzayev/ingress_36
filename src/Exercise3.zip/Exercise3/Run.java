package Exercise3;

public class Run {
    public static void main(String[] args) {
        Car car = new Car();
        car.startEngine();
        car.accelerate();
        car.brake();
    }
}
