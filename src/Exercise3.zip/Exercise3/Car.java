package Exercise3;

public class Car extends Vehicle implements Derivable {

    @Override
    public void accelerate() {
        System.out.println("Car is accelerating.");
    }

    @Override
    public void brake() {
        System.out.println("Car is braking.");


    }
}

