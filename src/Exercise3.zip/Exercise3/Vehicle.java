package Exercise3;

public class Vehicle {

    public void startEngine(){
        System.out.println("Engine started: ");
    }
}
